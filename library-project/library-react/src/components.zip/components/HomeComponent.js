import React from 'react';
import { useSelector } from 'react-redux';

const HomeComponent = () => {
    const state = useSelector(state => state);
    console.log(state);
    return (
        <>
        <h1>Home Component</h1>
        <h1>{state.token}</h1>
        </>
    )
}

export default HomeComponent;