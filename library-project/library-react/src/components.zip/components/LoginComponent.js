import React from 'react';

const LoginComponent = () => {
    return (
        <>
        <form>
            <table>
                <tr>
                    <td><label>Email</label></td>
                    <td> <input type='text' name='Email' id='Email' placeholder='Enter your email' /></td>
                </tr>
                <tr>
                    <td> <label>Password</label></td>
                    <td> <input type='text' name='Password' id='Password' placeholder='Enter your password' /></td>
                </tr>
                <tr>
                    <td/>
                    <td><button type='submit'>submit</button></td>
                </tr>
            </table>
        </form>
        </>
    )
}

export default LoginComponent;