import {createStore, applyMiddleware} from 'redux';
import { userRouter } from '../user/userRouter';
import thunk from 'redux-thunk';
export const store = createStore(userRouter, applyMiddleware(thunk));