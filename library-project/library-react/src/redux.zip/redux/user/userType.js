export const LOGIN = 'LOGIN';
export const SIGNUP = 'SIGNUP';