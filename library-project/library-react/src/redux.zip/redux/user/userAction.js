import { LOGIN } from "./userType";
import { SIGNUP } from "./userType";

export const login = () => {
    return {
        type: LOGIN,
    }
}

export const signup = () => {
    return {
        type: SIGNUP,
    }
}
